---
id: AD-001
title: The guid namespace string stays literally pyssp_sysml2
summary: The FMI guid is uuid5(NAMESPACE_URL, "pyssp_sysml2/<composition>/<component>") even though the package is named pyfmi_sysml2.
date: 2026-11-05
status: accepted
layers: [architecture]
state: docs/breakdown/02-architecture/determinism.md
artifacts:
  - src/pyfmi_sysml2/model_description.py
supersedes: []
superseded_by: []
related: []
---

# AD-001: The guid namespace string stays literally pyssp_sysml2

## Context

FMI `guid` values are stored by consumers and compared across rebuilds. The
v0.3.0 generator in `pyssp_sysml2` derived them from
`uuid5(NAMESPACE_URL, "pyssp_sysml2/<composition>/<component>")`. During the
split, both generators write into the same model directories, so the same
architecture may be built by either one.

## Decision

Keep the namespace input string verbatim: `pyssp_sysml2/` stays even though this
package is named `pyfmi_sysml2`. Only the module that computes it moved.

## Rationale

A guid is an identity, not a provenance label. Renaming the prefix would change
every guid and break comparisons against existing baselines for no functional
gain. The frozen string makes migration invisible to a consumer, and the test
pins it by recomputing the expected uuid from the literal.

## Alternatives Considered

Use `pyfmi_sysml2/` and accept a one-time guid change; rejected because it
silently breaks stored references. Parameterize the prefix; rejected because a
configurable identity is not an identity.

## Consequences

The prefix is a compatibility constant, not a rename target. Changing it is a
breaking change and needs its own decision record and a migration note.

## Verification

`tests/test_model_description.py::test_controller_guid_is_pinned` recomputes the
expected uuid from the literal string and compares it with the generated
document and `component_guid()`.

## Review Trigger

Revisit only if a consumer requires a new guid scheme; that is a breaking
change with its own migration.
