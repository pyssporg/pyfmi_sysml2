---
id: AD-002
title: inout and undirected ports become inputs
summary: FMI 2.0 has no bidirectional scalar, so inout and undirected ports are emitted as inputs and the Modelica connector keeps no direction qualifier.
date: 2026-11-05
status: accepted
layers: [product, architecture]
state: docs/breakdown/01-product/variable-model.md
artifacts:
  - src/pyfmi_sysml2/interface.py
  - src/pyfmi_sysml2/modelica.py
supersedes: []
superseded_by: []
related: []
---

# AD-002: inout and undirected ports become inputs

## Context

The dialect allows an `inout` port and a port usage without a direction. FMI 2.0
CoSimulation defines no bidirectional scalar variable: every ScalarVariable is
input, output, or parameter. A Modelica connector is a type, so one definition
used in different directions cannot carry a direction that is true for all
usages.

## Decision

Map `out` to `causality="output"` and everything else (`in`, `inout`,
undirected) to `causality="input"`. In the Modelica connector, emit an
`input`/`output` qualifier only when every usage agrees and none is
bidirectional; otherwise emit the member with no qualifier.

## Rationale

An input is the only FMI causality that both accepts a value from the host and
lets the component read it; it is the closest legal approximation. Refusing the
model would reject architectures that are valid SysML, and inventing a paired
input/output would double the VR set without a consumer contract. The connector
rule keeps the generated package loadable on both sides of a connection.

## Alternatives Considered

Reject `inout` at generation; rejected because the dialect permits it. Emit two
ScalarVariables per field; rejected because the variable set would no longer be
one scalar per authored field.

## Consequences

A bidirectional signal loses direction information in FMI and the consumer must
know the convention. The Modelica side stays undirected, which is valid but
weaker than an explicit direction.

## Verification

`tests/test_model_description.py` checks the Controller's `inout` port is an
input; `tests/test_modelica.py` checks mixed and bidirectional usages stay
undirected; the header test checks the writable flag follows causality.

## Review Trigger

Revisit if FMI 3.0 or a host-specific bidirectional convention enters scope.
